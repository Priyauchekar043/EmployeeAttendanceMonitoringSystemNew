package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.dao.BaseDAO;
import com.model.Admin;
import com.rowmapper.AdminRowMapper;
import com.dao.AdminDAO;


/**
 * @author puchekar
 *
 */
@Service
public class AdminServiceImpl extends BaseDAO implements AdminService{
    
    @Autowired
    private AdminDAO contactDAO;
    
    @Override    
    public void save(Admin c) {
        contactDAO.save(c);
    }

    
    @Override
    public Admin login(String email, String password)
    {
        String sql = "SELECT adminId,userId, name,lastname, phone, email, address, password"
                + " FROM admin WHERE email=:em AND password=:pw";
       
        Map m = new HashMap();
        m.put("em", email);
        m.put("pw", password);
        
        
        
        
        try {
       
		
		  Admin c = getNamedParameterJdbcTemplate().queryForObject(sql, m, new AdminRowMapper());
		  return c;
        }catch(EmptyResultDataAccessException e)
        {
          
           return null;
            }
   
    }
	
    @Override
    public List<Admin> getContactList() {
        return contactDAO.findAll();
    }

	
    
    
 

}