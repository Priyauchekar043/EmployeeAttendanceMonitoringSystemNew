package com.service;

import java.util.List;

import com.model.Attend;


/**
 * @author puchekar
 *
 */
public interface AttendanceService {
	public void save(Attend s);

	public void update(Attend s);

	 public List<Attend> getattendList();

	public Attend findById(Integer aId);

	public List<Attend> findByUserId(Integer userId);

	 


}
