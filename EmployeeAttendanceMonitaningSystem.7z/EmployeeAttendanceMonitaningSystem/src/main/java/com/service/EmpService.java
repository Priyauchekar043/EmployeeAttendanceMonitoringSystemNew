package com.service;

import java.util.List;

import com.customexception.EmpBlockedException;
import com.model.Emp;


/**
 * @author puchekar
 *
 */
public interface EmpService {
    
    public static final Integer LOGIN_STATUS_ACTIVE=1;
    public static final Integer LOGIN_STATUS_BLOCKED=2;
    
    public static final Integer ROLE_ADMINSTAFF=1;
    public static final Integer ROLE_EMP=2;
    
    
   
    public void register(Emp u);
    
   
    public Emp login(String loginName, String password) throws EmpBlockedException;
    
    public void changeLoginStatus(Integer userId, Integer loginStatus); 
    
     public Boolean isUsernameExist(String username);
 
     
     public List<Emp> getUserList();
    
    public void update(Emp u);
    
    public Emp findById(Integer userId);
		
    
    public void delete(Integer userId);
    
    public void delete(Integer[] userIds);


	//List<Emp> findUser(Integer userId, String txt);


	List<Emp> findUser(String txt);
    

	
   
}
