package com.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.BaseDAO;
import com.dao.LeaveDAO;

import com.model.Leave;
import com.rowmapper.LeaveRowMapper;
/**
 * @author puchekar
 *
 */
@Service
public class LeaveServiceImpl extends BaseDAO implements LeaveService {

	 @Autowired
	    private LeaveDAO leaveDAO;
	    
	    @Override    
	    public void save(Leave l) {
	        leaveDAO.save(l);
	    }

		@Override
		public void update(Leave l) {
			leaveDAO.update(l);
			
		}

		@Override
		public List<Leave> findUserLeave() {
			
			 return leaveDAO.findAll();
		}

		 

		    @Override
		    public List<Leave> findUserLeave1(Integer userId, String txt) {
		        String sql = "SELECT leaveId, date1, date2, userId, count, totalleave, reaminleave, reason,comment FROM leave2 WHERE userId=? AND (leaveId LIKE '%"+txt+"%' OR date1 LIKE '%"+txt+"%' OR date2 LIKE '%"+txt+"%' OR userId LIKE '%"+txt+"%' OR count LIKE '%"+txt+"%' OR totalleave LIKE '%"+txt+"%' OR reaminleave LIKE '%"+txt+"%' OR reason LIKE '%"+txt+"%' OR comment LIKE '%"+txt+"%')";
		        return getJdbcTemplate().query(sql, new LeaveRowMapper(),userId); 
		    }

		    @Override
		    public Leave findById(Integer leaveId) {
		        return leaveDAO.findById(leaveId);
		    }

			@Override
			public List<Leave> findByUserId(int userId) {
				// TODO Auto-generated method stub
				return leaveDAO.findByUserId(userId);
			}

			@Override
			public List<Leave> findByProperty(String string, Object propValue) {
				// TODO Auto-generated method stub
				return leaveDAO.findByProperty(string, propValue);
			}

		
		
			 @Override
			    public List<Leave> findUserContact(Integer userId) {
			        return leaveDAO.findByProperty("userId", userId);
			    }
		
}
