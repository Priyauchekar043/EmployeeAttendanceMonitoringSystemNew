package com.service;

import java.util.List;

import com.model.Leave;

/**
 * @author puchekar
 *
 */
public interface LeaveService {

	public void save(Leave l);

	public void update(Leave l);

	public List<Leave> findUserLeave();

	public List<Leave> findUserLeave1(Integer userId, String txt);

	

	public Leave findById(Integer leaveId);

	public List<Leave> findByUserId(int userId);

	List<Leave> findByProperty(String string, Object propValue);

	/* public Leave findUserLeave(Integer userId, Integer userId2); */
	 public List<Leave> findUserContact(Integer userId);

}
