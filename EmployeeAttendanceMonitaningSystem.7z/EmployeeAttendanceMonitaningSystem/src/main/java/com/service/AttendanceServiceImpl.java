package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.AttendanceDAO;
import com.dao.BaseDAO;
import com.model.Attend;



/**
 * @author puchekar
 *
 */
@Service
public class AttendanceServiceImpl extends BaseDAO implements AttendanceService {

	 @Autowired
	    private AttendanceDAO attendDAO;
	@Override
	public void save(Attend s) 
	{
		 attendDAO.save(s);
		
		
	}
	@Override
	public void update(Attend s) {
		attendDAO.update(s);
		
	}
	
	 @Override
	    public List<Attend> getattendList() {
	        return attendDAO.findAll();
	    }
	@Override
	public Attend findById(Integer aId) {
		return attendDAO.findById(aId);
		
	}
	@Override
	public List<Attend> findByUserId(Integer userId) {
		// TODO Auto-generated method stub
		return attendDAO.findByUserId(userId);
	}
	 
	    
}
