package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.customexception.EmpBlockedException;
import com.dao.BaseDAO;
import com.dao.EmpDAO;

import com.model.Emp;
import com.rowmapper.EmpRowMapper;
import com.util.StringUtil;


/**
 * @author puchekar
 *
 */
@Service
public class EmpServiceImpl extends BaseDAO implements EmpService {

    @Autowired
    private EmpDAO userDAO;

    @Override
    public void register(Emp u) {
        userDAO.save(u);
    }
    
    

    @Override
    public void update(Emp u) {
        userDAO.update(u);
    }

    @Override
    public Emp login(String loginName, String password) throws EmpBlockedException {
        String sql = "SELECT userId, name, lastname, phone, email, address, role, loginStatus, loginName"
                + " FROM Employee1 WHERE loginName=:ln AND password=:pw";
        Map m = new HashMap();
        m.put("ln", loginName);
        m.put("pw", password);
        try {
            Emp u = getNamedParameterJdbcTemplate().queryForObject(sql, m, new EmpRowMapper());
            if (u.getLoginStatus().equals(EmpService.LOGIN_STATUS_BLOCKED)) {
                throw new EmpBlockedException("Your account has been blocked. Contact to admin.");
            } else {
                return u;
            }
        } catch (EmptyResultDataAccessException ex) {
            return null;
        }
    }

    @Override
    public List<Emp> getUserList() {
    	// System.out.println("pageidfromservice" +pageid);
    	// System.out.println("totalfromservice" +total);
		/* return userDAO.findByProperty("role", EmpService.ROLE_EMP, pageid, total); */
    	 return userDAO.findByProperty("role", EmpService.ROLE_EMP);
    }
    
    

    @Override
    public void changeLoginStatus(Integer userId, Integer loginStatus) {
        String sql = "UPDATE Employee1 SET loginStatus=:lst WHERE userId=:uid";
        Map m = new HashMap();
        m.put("uid", userId);
        m.put("lst", loginStatus);
        getNamedParameterJdbcTemplate().update(sql, m);
    }

    @Override
    public Boolean isUsernameExist(String username) {
        String sql = "SELECT count(loginName) FROM Employee1 WHERE loginName=?";
        Integer count = getJdbcTemplate().queryForObject(sql, new String[]{username}, Integer.class);
        if(count==1){
            return true;
        }else{
            return false;
        }
    }



	@Override
	public Emp findById(Integer userId) {
		
		return userDAO.findById(userId);
	}


   
	  @Override
	    public void delete(Integer userId) {
	        userDAO.delete(userId);
	    }

	    @Override
	    public void delete(Integer[] userIds) {
	        String ids = StringUtil.toCommaSeparatedString(userIds);
	        String sql = "DELETE FROM Employee1 WHERE userId IN("+ids+")";
	        getJdbcTemplate().update(sql);
	    }
	    
	    
	    @Override
	    public List<Emp> findUser(String txt) {
	        String sql = "SELECT  userId, name,lastname, phone, email, address, role, loginStatus, loginName FROM Employee1  Where (name LIKE '%"+txt+"%'   OR lastname LIKE '%"+txt+"%' OR userId LIKE '%"+txt+"%' OR address LIKE '%"+txt+"%' OR phone LIKE '%"+txt+"%' OR email LIKE '%"+txt+"%' OR role LIKE '%"+txt+"%' OR loginStatus LIKE '%"+txt+"%' OR loginName LIKE '%"+txt+"%')";
	        return getJdbcTemplate().query(sql, new EmpRowMapper()); 
	        
	    }

	    
}
