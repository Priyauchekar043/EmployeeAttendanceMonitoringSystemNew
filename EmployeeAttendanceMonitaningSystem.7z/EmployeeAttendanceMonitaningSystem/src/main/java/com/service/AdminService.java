package com.service;

import java.util.List;

import com.model.Admin;




/**
 * @author puchekar
 *
 */
public interface AdminService {

    public void save(Admin c);

	

	 public Admin login(String email, String password); 
   
    public List<Admin> getContactList();

	

  
	
}
