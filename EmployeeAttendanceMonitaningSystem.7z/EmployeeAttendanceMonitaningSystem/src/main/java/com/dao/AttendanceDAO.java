package com.dao;

import java.util.List;

import com.model.Attend;

/**
 * @author puchekar
 *
 */
public interface AttendanceDAO {
	
	public void save(Attend s);

	public void update(Attend s);

	 public List<Attend> findAll();

	public Attend findById(Integer aId);

	public List<Attend> findByUserId(Integer userId);

}
