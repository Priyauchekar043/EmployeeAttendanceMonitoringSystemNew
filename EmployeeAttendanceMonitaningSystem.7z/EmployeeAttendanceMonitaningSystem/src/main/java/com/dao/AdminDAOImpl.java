package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.model.Admin;
import com.rowmapper.AdminRowMapper;




/**
 * @author puchekar
 *
 */
@Repository
public class AdminDAOImpl extends BaseDAO implements AdminDAO {

   
    
    @Override
    public void save(Admin c) {
        String sql = "INSERT INTO admin( name,lastname,userId, phone, email, address,password) VALUES( :name,:lastname,:userId, :phone, :email, :address,:password)";
        Map m = new HashMap();
       
        m.put("name", c.getName());
        m.put("lastname", c.getLastname());
        m.put("phone", c.getPhone());
        m.put("email", c.getEmail());
        m.put("address", c.getAddress());
       m.put("password", c.getPassword());
       m.put("userId", c.getUserId());
       
        SqlParameterSource ps = new MapSqlParameterSource(m);
        KeyHolder kh = new GeneratedKeyHolder();
        getNamedParameterJdbcTemplate().update(sql, ps, kh);
        c.setAdminId(kh.getKey().intValue());
    }

	

    @Override
    public List <Admin> findAll() {
        String sql = "SELECT adminId,userId, name,lastname,phone, email, address,password FROM admin";
        return getJdbcTemplate().query(sql, new AdminRowMapper());
    }
	
	  @Override public List <Admin> findByProperty(String propName, Object
	  propValue) { String sql =
	  "SELECT adminId, userId, name,lastname, phone, email, address, password FROM admin WHERE "
	  +propName+"=?"; return getJdbcTemplate().query(sql, new AdminRowMapper(),
	  propValue); }
	 

	
}
