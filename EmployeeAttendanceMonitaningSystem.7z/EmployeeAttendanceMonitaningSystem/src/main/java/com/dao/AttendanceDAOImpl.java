package com.dao;

import java.util.HashMap;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.model.Attend;
import com.rowmapper.AttendanceRowmapper;

/**
 * @author puchekar
 *
 */
@Repository
public class AttendanceDAOImpl extends BaseDAO implements AttendanceDAO {

	@Override
	public void save(Attend s) {
		System.out.println("From DAO"+s);
		String sql = "INSERT INTO Empattendance1 (userId,attenddays,date,empleave,totalattenddays,salary) VALUES(:userId, :attenddays,:date,:empleave, :totalattenddays, :salary)";
		Map m = new HashMap();
		m.put("userId", s.getUserId());
		m.put("attenddays", s.getAttenddays());
		m.put("date", s.getDate());	
		m.put("empleave", s.getEmpleave());
		m.put("totalattenddays", s.getTotalattenddays());
		m.put("salary", s.getSalary());

		SqlParameterSource ps = new MapSqlParameterSource(m);
		KeyHolder kh = new GeneratedKeyHolder();
		getNamedParameterJdbcTemplate().update(sql, ps, kh);
		s.setaId(kh.getKey().intValue());

	}

	@Override
	public void update(Attend s) {
		String sql = "UPDATE  Empattendance1 SET "
				+ "attenddays =:attenddays, date=:date,empleave=:empleave, totalattenddays=:totalattenddays, salary=:salary WHERE aId=:aId";
		Map m = new HashMap();
		m.put("userId", s.getUserId());
		m.put("date", s.getDate());	
		m.put("aId", s.getaId());
		m.put("attenddays", s.getAttenddays());
		m.put("empleave", s.getEmpleave());
		m.put("totalattenddays", s.getTotalattenddays());
		m.put("salary", s.getSalary());
		getNamedParameterJdbcTemplate().update(sql, m);

	}

	@Override
	public List<Attend> findAll() {
		String sql = "SELECT aId, userId, attenddays, date, empleave, totalattenddays, salary FROM Empattendance1";
		return getJdbcTemplate().query(sql, new AttendanceRowmapper());
	}

	@Override
	public Attend findById(Integer aId) {

		String sql = "SELECT aId, userId, attenddays, date, empleave, totalattenddays, salary FROM Empattendance1 WHERE aId=?";
		return getJdbcTemplate().queryForObject(sql, new AttendanceRowmapper(), aId);
	}

	@Override
	public List<Attend> findByUserId(Integer userId) {

		String sql = "SELECT aId, userId, attenddays, date,  empleave, totalattenddays, salary FROM Empattendance1 WHERE userId=?";
		return getJdbcTemplate().query(sql, new AttendanceRowmapper(), userId);

	}

}
