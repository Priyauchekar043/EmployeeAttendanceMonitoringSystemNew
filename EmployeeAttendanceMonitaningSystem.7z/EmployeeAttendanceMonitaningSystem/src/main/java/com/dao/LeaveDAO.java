package com.dao;


import java.util.List;

import com.model.Leave;



/**
 * @author puchekar
 *
 */
public interface LeaveDAO {

	 public void save(Leave l);

	public void update(Leave l);

	public List<Leave> findByProperty(String string, Object propValue);

	 public List<Leave> findAll();
	
	public Leave findById(Integer leaveId);

	 public List<Leave> findByUserId(int userId);
	 
	 public void updateLeave(int sum, Integer userId); 
	 
	 
}
