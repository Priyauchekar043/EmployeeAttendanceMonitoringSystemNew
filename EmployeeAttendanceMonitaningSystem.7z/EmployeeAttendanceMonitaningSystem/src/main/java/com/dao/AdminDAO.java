package com.dao;

import java.util.List;

import com.model.Admin;



/**
 * @author puchekar
 *
 */
public interface AdminDAO {

    public void save(Admin c);
    public List<Admin> findAll();

	
	 
	 
	 
	 public List<Admin> findByProperty(String propName, Object propValue);
	 
}
