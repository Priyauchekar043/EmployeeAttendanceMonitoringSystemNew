package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.model.Emp;
import com.rowmapper.EmpRowMapper;

/**
 * @author puchekar
 *
 */
@Repository
public class EmpDAOImpl extends BaseDAO implements EmpDAO {

	@Override
	public void save(Emp u) {
		String sql = "INSERT INTO Employee1(name,lastname, phone, email, address, loginName, password, role, loginStatus)"
				+ " VALUES(:name,:lastname, :phone, :email, :address, :loginName, :password, :role, :loginStatus)";
		Map m = new HashMap();
		m.put("name", u.getName());
		m.put("lastname", u.getLastname());
		m.put("phone", u.getPhone());
		m.put("email", u.getEmail());
		m.put("address", u.getAddress());
		m.put("loginName", u.getLoginName());
		m.put("password", u.getPassword());
		m.put("role", u.getRole());
		m.put("loginStatus", u.getLoginStatus());

		KeyHolder kh = new GeneratedKeyHolder();
		SqlParameterSource ps = new MapSqlParameterSource(m);
		super.getNamedParameterJdbcTemplate().update(sql, ps, kh);
		Integer userId = kh.getKey().intValue();
		u.setUserId(userId);
	}

	@Override
	public void delete(Emp u) {
		this.delete(u.getUserId());
	}

	@Override
	public void delete(Integer userId) {
		String sql = "DELETE FROM Employee1 WHERE userId=?";
		getJdbcTemplate().update(sql, userId);
	}

	@Override
	public Emp findById(Integer userId) {
		String sql = "SELECT userId, name,lastname, phone, email, address, loginName, role, loginStatus"
				+ " FROM Employee1 WHERE userId=?";
		Emp u = getJdbcTemplate().queryForObject(sql, new EmpRowMapper(), userId);
		return u;
	}

	@Override
	public List<Emp> findAll() {
		String sql = "SELECT userId, name,lastname, phone, email, address, loginName, role, loginStatus" + " FROM Employee1";

		return getJdbcTemplate().query(sql, new EmpRowMapper());
	}

	@Override
	public List<Emp> findByProperty(String propName, Object propValue) {
		/*
		 * String sql =
		 * "SELECT  * FROM Employee1  WHERE "+propName+"=? "+(pageid-1)+","+total;
		 */
		String sql = "SELECT * FROM Employee1 WHERE " + propName + "=?";
		System.out.println("role----" + propName);
		System.out.println("value----" + propValue);

		
		return getJdbcTemplate().query(sql, new EmpRowMapper(), propValue);
	}

	/*
	 * @Override public List<Emp> findByProperty(String propName, Object
	 * propValue,int pageid, int total) {
	 * 
	 * String sql =
	 * "SELECT  * FROM Employee1  WHERE "+propName+"=? "+(pageid-1)+","+total;
	 * 
	 * String sql =
	 * "SELECT * FROM Employee1 WHERE "+propName+"=? LIMIT "+(pageid-1)+","+total;
	 * System.out.println("role----"+propName);
	 * System.out.println("value----"+propValue);
	 * 
	 * System.out.println("pageid:--"+(pageid-1));
	 * System.out.println("total:---"+total); return getJdbcTemplate().query(sql,
	 * new EmpRowMapper(), propValue); }
	 */

	@Override
	public void update(Emp u) {
		System.out.println("formDAO" + u);
		String sql = "UPDATE Employee1 " + " SET name=:name,  " + " lastname=:lastname, " + " phone=:phone, " + " email=:email,"
				+ " address=:address,"

				+ " role=:role," + " loginStatus=:loginStatus " + " WHERE userId=:userId";
		Map m = new HashMap();

		m.put("name", u.getName());
		m.put("lastname", u.getLastname());
		m.put("phone", u.getPhone());
		m.put("email", u.getEmail());
		m.put("address", u.getAddress());

		m.put("role", u.getRole());
		m.put("loginStatus", u.getLoginStatus());
		m.put("userId", u.getUserId());
		System.out.println("update emp" + m);
		getNamedParameterJdbcTemplate().update(sql, m);
	}

}
