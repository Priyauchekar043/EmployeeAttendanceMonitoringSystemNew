package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.model.Leave;
import com.rowmapper.LeaveRowMapper;
/**
 * @author puchekar
 *
 */
@Repository
public class LeaveDAOImpl extends BaseDAO implements LeaveDAO  {

	@Override
	public void save(Leave l) {
		
		        String sql = "INSERT INTO leave2 (userId, date1, date2,   totalleave, count, reaminleave, reason,comment) VALUES(:userId,:date1, :date2,:totalleave,:count,:reaminleave, :reason, :comment)";
		        Map m = new HashMap();
		        m.put("userId", l.getUserId());
		        m.put("date1", l.getDate1());
		        m.put("date2", l.getDate2());
		       m.put("totalleave", l.getTotalleave());
		        m.put("count", l.getCount());
		        m.put("reaminleave", l.getReaminleave());
		        m.put("reason", l.getReason());
		        m.put("comment", l.getComment());
		       
		        SqlParameterSource ps = new MapSqlParameterSource(m);
		        KeyHolder kh = new GeneratedKeyHolder();
		        getNamedParameterJdbcTemplate().update(sql, ps, kh);
		        l.setLeaveId(kh.getKey().intValue());
		    

		
		        
		
	}
	
	  @Override public void update(Leave l) {
	  
	  String sql =
	  "UPDATE leave2 SET leaveId=:leaveId, date1=:date1, date2=:date2, count=:count, reason=:reason, totalleave=:totalleave, reaminleave=:reaminleave, comment=:comment, userId=:userId  WHERE leaveId=:leaveId"
	  ; Map m = new HashMap(); 
	  m.put("leaveId", l.getLeaveId());
	  m.put("count",l.getCount());
	  m.put("date1", l.getDate1());
      m.put("date2", l.getDate2());
      m.put("totalleave",l.getTotalleave());
	  m.put("userId", l.getUserId());
	  m.put("reason",l.getReason()); 
	  m.put("comment", l.getComment());
	  getNamedParameterJdbcTemplate().update(sql, m); }
	 

	 @Override
	    public List<Leave> findByProperty(String propName, Object propValue) {
	        String sql = "SELECT leaveId, date1, date2, userId, count, totalleave, reaminleave, reason,comment FROM leave2 WHERE "+propName+"=?";
	        return getJdbcTemplate().query(sql, new LeaveRowMapper(), propValue);
	    }
	 		
	 @Override
	    public List<Leave> findByUserId(int userId) {
	        String sql = "SELECT leaveId, date1, date2, userId, totalleave, count, reaminleave, reason, comment FROM leave2 WHERE userId=?";
	        return getJdbcTemplate().query(sql, new LeaveRowMapper(), userId);
	    }

	
	 

	    @Override
	    public List<Leave> findAll() {
	        String sql = "SELECT leaveId, date1, date2, userId,  totalleave, count, reaminleave, reason, comment  FROM leave2";
	        return getJdbcTemplate().query(sql, new LeaveRowMapper());
	    }

	    @Override
	    public Leave findById(Integer leaveId) {
	        String sql = "SELECT leaveId, date1, date2,  userId, count, totalleave, reaminleave, reason, comment  FROM leave2 WHERE leaveId=?";
	        return getJdbcTemplate().queryForObject(sql, new LeaveRowMapper(), leaveId);
	    }
	

		@Override
		public void updateLeave(int sum, Integer userId) {
			// TODO Auto-generated method stub
			
		}

		
	
	
	
	

}
