package com.dao;

import java.util.List;

import com.model.Emp;


/**
 * @author puchekar
 *
 */
public interface EmpDAO {

    public void save(Emp u);

    public void update(Emp u);

    public void delete(Emp u);

    public void delete(Integer userId);

    public Emp findById(Integer userId);

    public List<Emp> findAll();

    public List<Emp> findByProperty(String propName, Object propValue);

	/*
	 * public List<Emp> findByProperty(String propName, Object propValue,int pageid,
	 * int total);
	 */
	
}
