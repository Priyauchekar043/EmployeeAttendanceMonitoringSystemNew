package com.model;

import java.util.Date;

/**
 * @author puchekar
 *
 */
public class Leave {
	private int leaveId;//pk
	private Date date1;
	private Date date2;
	private int totalleave;
	private int count;
	private int reaminleave;
	private String  Reason;
	private String comment;
	private int UserId;//pk
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		UserId = userId;
	}
	public int getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public Date getDate1() {
		return date1;
	}
	public void setDate1(Date date1) {
		this.date1 = date1;
	}
	public Date getDate2() {
		return date2;
	}
	public void setDate2(Date date2) {
		this.date2 = date2;
	}
	public String getReason() {
		return Reason;
	}
	public void setReason(String reason) {
		Reason = reason;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	public int getReaminleave() {
		return reaminleave;
	}
	public void setReaminleave(int reaminleave) {
		this.reaminleave = reaminleave;
	}
	public int getTotalleave() {
		return totalleave;
	}
	public void setTotalleave(int totalleave) {
		this.totalleave = totalleave;
	}
	@Override
	public String toString() {
		return "Leave [leaveId=" + leaveId + ", date1=" + date1 + ", date2=" + date2 + ", totalleave=" + totalleave
				+ ", count=" + count + ", reaminleave=" + reaminleave + ", Reason=" + Reason + ", comment=" + comment
				+ ", UserId=" + UserId + "]";
	}
	

}
