package com.model;

import java.util.Date;

/**
 * @author puchekar
 *
 */
public class Attend {
	
	 private Integer userId;//Fk
	   
	    private Integer aId;//PK
        private String date;
	   // private Date date;
	    private Integer attenddays;
	    private Integer empleave;
	    private Integer totalattenddays;
	    private Integer salary;
	    
	    
		
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
		public Integer getUserId() {
			return userId;
		}
		public void setUserId(Integer userId) {
			this.userId = userId;
		}
		public Integer getaId() {
			return aId;
		}
		public void setaId(Integer aId) {
			this.aId = aId;
		}
		public Integer getAttenddays() {
			return attenddays;
		}
		public void setAttenddays(Integer attenddays) {
			this.attenddays = attenddays;
		}
		public Integer getEmpleave() {
			return empleave;
		}
		public void setEmpleave(Integer empleave) {
			this.empleave = empleave;
		}
		public Integer getTotalattenddays() {
			return totalattenddays;
		}
		public void setTotalattenddays(Integer totalattenddays) {
			this.totalattenddays = totalattenddays;
		}
		public Integer getSalary() {
			return salary;
		}
		public void setSalary(Integer salary) {
			this.salary = salary;
		}
		@Override
		public String toString() {
			return "Attend [userId=" + userId + ", aId=" + aId + ", date=" + date + ", attenddays=" + attenddays
					+ ", empleave=" + empleave + ", totalattenddays=" + totalattenddays + ", salary=" + salary + "]";
		}
		
		
	/*
	 * public Date getDate() { return date; } public void setDate(Date date) {
	 * this.date = date; }
	 * 
	 * @Override public String toString() { return "Attend [userId=" + userId +
	 * ", aId=" + aId + ", date=" + date + ", attenddays=" + attenddays +
	 * ", empleave=" + empleave + ", totalattenddays=" + totalattenddays +
	 * ", salary=" + salary + "]"; }
	 */
		
		

}
