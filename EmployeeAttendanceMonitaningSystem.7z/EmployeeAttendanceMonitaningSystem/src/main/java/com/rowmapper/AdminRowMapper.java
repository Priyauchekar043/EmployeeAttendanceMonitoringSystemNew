package com.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.model.Admin;




/**
 * @author puchekar
 *
 */
public class AdminRowMapper implements RowMapper<Admin>{
    @Override
    public Admin mapRow(ResultSet rs, int i) throws SQLException {
        Admin c=new Admin();
        c.setAdminId(rs.getInt("adminId"));
        c.setUserId(rs.getInt("userId"));
        c.setName(rs.getString("name"));
        c.setLastname(rs.getString("lastname"));
        c.setEmail(rs.getString("email"));
        c.setAddress(rs.getString("address"));       
        c.setPhone(rs.getString("phone"));       
       c.setPassword(rs.getString("password"));             
        return c;
    }
    
}
