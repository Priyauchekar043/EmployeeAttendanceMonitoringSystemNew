package com.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.model.Attend;


/**
 * @author puchekar
 *
 */
public class AttendanceRowmapper implements RowMapper<Attend>{
    
    @Override
    public Attend mapRow(ResultSet rs, int i) throws SQLException {
        Attend s=new Attend();
       s.setUserId(rs.getInt("userId"));
       s.setaId(rs.getInt("aId"));
    // s.setDate(rs.getDate("date"));
     //  s.setDate(rs.getString("date"));
       s.setDate(rs.getString("date"));
       s.setAttenddays(rs.getInt("attenddays"));
       s.setEmpleave(rs.getInt("empleave"));
       s.setTotalattenddays(rs.getInt("totalattenddays"));
       s.setSalary(rs.getInt("salary"));
//                  System.out.println("Ffrom Row mapper"+s);
        return s;
    }
	
	

}
