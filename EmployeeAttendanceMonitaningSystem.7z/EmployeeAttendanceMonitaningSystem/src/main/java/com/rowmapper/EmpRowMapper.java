package com.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.model.Emp;

/**
 * @author puchekar
 *
 */
public class EmpRowMapper implements RowMapper<Emp>{
    @Override
    public Emp mapRow(ResultSet rs, int i) throws SQLException {
        Emp u=new Emp();
        u.setUserId(rs.getInt("userId"));
      
        u.setName(rs.getString("name"));
        u.setLastname(rs.getString("lastname"));
        u.setPhone(rs.getString("phone"));
        u.setEmail(rs.getString("email"));
        u.setAddress(rs.getString("address"));
        u.setLoginName(rs.getString("loginName"));
      
        u.setRole(rs.getInt("role"));
        u.setLoginStatus(rs.getInt("loginStatus"));
        return u;
    }    
}
