package com.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.model.Leave;

/**
 * @author puchekar
 *
 */
public class LeaveRowMapper implements RowMapper<Leave>{
    @Override
    public Leave mapRow(ResultSet rs, int i) throws SQLException {
        Leave l=new Leave();
       l.setUserId(rs.getInt("userId"));
       l.setLeaveId(rs.getInt("leaveId"));
       l.setDate1(rs.getDate("date1"));
       l.setDate2(rs.getDate("date2"));
       l.setTotalleave(rs.getInt("totalleave"));
       l.setCount(rs.getInt("count"));
       l.setReaminleave(rs.getInt("reaminleave"));
       l.setReason(rs.getString("reason"));
       l.setComment(rs.getString("comment"));
                  
        return l;
    }}
    