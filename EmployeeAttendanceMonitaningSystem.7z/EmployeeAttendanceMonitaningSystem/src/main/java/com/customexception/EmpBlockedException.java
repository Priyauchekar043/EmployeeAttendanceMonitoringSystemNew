package com.customexception;


/**
 * @author puchekar
 *
 */
public class EmpBlockedException extends Exception{
    
    public EmpBlockedException() {
    }
   
    public EmpBlockedException(String errDesc) {
        super(errDesc);
    }    
}
