package com.command;

import com.model.Emp;


/**
 * @author puchekar
 *
 */
public class EmpCommand {
    Emp user;
   
    public Emp getUser() {
        return user;
    }

    public void setUser(Emp user) {
        this.user = user;
    }

	@Override
	public String toString() {
		return "EmpCommand [user=" + user + "]";
	}
    
    
}
