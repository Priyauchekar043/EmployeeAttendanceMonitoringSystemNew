package com.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


import com.model.Leave;

import com.service.LeaveService;

@Controller
public class LeaveController {
	@Autowired
	private LeaveService leaveService;
	
	

	/**
	 * @param m
	 * @return
	 */
	@RequestMapping(value = "/user1/leave_form")
	public String contactForm(Model m) {
		Leave leave = new Leave();
		m.addAttribute("command", leave);
		return "Applyleave";// JSP form view
	}

	/**
	 * @param l
	 * @param m
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/user/save_leave")
	public String saveOrUpdateContact(@ModelAttribute("command") Leave l,Model m, HttpSession session) {
		Integer leaveId = (Integer) session.getAttribute("aLeaveId");
		l.setTotalleave(2);
		l.setReaminleave(0);
		
		if (leaveId == null) {
			// save task
			try {
				Integer userId = (Integer) session.getAttribute("userId");
				System.out.println("userId " + userId);
				l.setUserId(userId);// FK ; logged in userId
				System.out.println("Count..."+l.getCount());
				/*
				 * Integer empleave = (Integer) session.getAttribute("empleave");
				 * System.out.println("empleave " + empleave); s.setEmpleave(empleave);
				 */
				
				
				 l.setReaminleave(l.getTotalleave() - l.getCount());
				System.out.println("Leavecountupdate"+l);
				 
				System.out.println(""+l.getTotalleave());
				leaveService.save(l);
				m.addAttribute("leaveList","Leave apply successfully");
				return "Applyleave";
			} catch (Exception e) {
				e.printStackTrace();
				m.addAttribute("err", "Failed to save leave");
				return "Applyleave";
			}
		} else {
			// update task
			try {
				l.setLeaveId(leaveId); // PK
				leaveService.update(l);
				session.removeAttribute("aLeaveId");
				return "redirect:leavelist?act=ed";
			} catch (Exception e) {
				e.printStackTrace();
				m.addAttribute("err", "Failed to Edit Leave");
				return "Applyleave";
			}
		}
	}
	

	

	
	/**
	 * @param l
	 * @param m
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/user/save_leave1")
	public String Leavelist (@ModelAttribute("command") Leave l, Model m, HttpSession session) {
		Integer leaveId = (Integer) session.getAttribute("aLeaveId");
		 {
			
			try {
				Integer userId = (Integer) session.getAttribute("userId");
			
				List<Leave> lList=leaveService.findByProperty("userId",userId);
				System.out.println("laeve count: "+lList);
				int sum=0;
				for (Leave leave : lList) {
					sum+=leave.getCount();
				}
				System.out.println(sum);
				
				

				m.addAttribute("leaveList", leaveService.findUserLeave());
				return "leavelist";// redirect user to contact list url
			} catch (Exception e) {
				e.printStackTrace();
				m.addAttribute("err", "Failed to save leave");
				return "Applyleave";
			}
		
		 }
	
		 }
	
		 /**
		 * @param l
		 * @param m
		 * @param session
		 * @return
		 */
		@RequestMapping(value = "/user/save_leavecount1")
			public String Leavemanagement1 (@ModelAttribute("command") Leave l, Model m, HttpSession session) {
				Integer leaveId = (Integer) session.getAttribute("aLeaveId");
				 {
					
					try {
						
					
						List<Leave> lList=leaveService.findUserLeave();
						System.out.println("laeve count: "+lList);
						int sum=0;
						for (Leave leave : lList) {
							sum+=leave.getCount();
						}
						System.out.println(sum);
						

						m.addAttribute("sum1", sum);
						m.addAttribute("showAll", true);
						m.addAttribute("showOne", false);
						m.addAttribute("lList", lList);
						
						return "leavecount";// redirect user to contact list url
					} catch (Exception e) {
						e.printStackTrace();
						m.addAttribute("err", "Failed to save leave");
						return "Applyleave";
					}
				
			}
				 
	}
		 
		 /**
		 * @param l
		 * @param m
		 * @param session
		 * @return
		 */
		@RequestMapping(value = "/user/contact_search")
		    public String contactSearch(@ModelAttribute("command") Leave l,Model m, HttpSession session) {
		        Integer userId = (Integer) session.getAttribute("userId");
		        System.out.println(userId);
		        
		        
		        List<Leave> list = leaveService.findByUserId(l.getUserId());
		        System.out.println("searched list"+list);
		        
		        int sum=0;
				for (Leave leave : list) {
					sum+=leave.getCount();
				}
				System.out.println(sum);
				

				m.addAttribute("sum1", sum);
		   
		        m.addAttribute("showAll", false);
				m.addAttribute("showOne", true);
		        m.addAttribute("lList", list);
		        return "leavecount"; //JSP
		    }

		
}