package com.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.command.AdminCommand;
import com.command.EmpCommand;
import com.command.LoginCommand;
import com.customexception.EmpBlockedException;
import com.model.Attend;
import com.model.Emp;
import com.service.AttendanceService;
import com.service.EmpService;

/**
 * @author puchekar
 *
 */
@Controller
public class EmpController {

	@Autowired
	private EmpService userService;

	@Autowired
	private AttendanceService attendanceService;

	/**
	 * @param m
	 * @return
	 */
	@RequestMapping(value = { "/", "/index" })
	public String index(Model m) {
		m.addAttribute("command", new LoginCommand());
		return "index";
	}

	
	  @RequestMapping(value = "/login1")
	    public String userLogin1(@ModelAttribute("command") LoginCommand cmd) {
	    	return "login";
	    }
	
	/**
	 * @param cmd
	 * @param m
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/login", method = { RequestMethod.GET, RequestMethod.POST })
	public String handleLogin(@ModelAttribute("command") LoginCommand cmd, Model m, HttpSession session) {
		try {
			System.out.println("asvv"+cmd);
			Emp loggedInUser = userService.login(cmd.getLoginName(), cmd.getPassword());
			System.out.println("avdbb"+loggedInUser);
			if (loggedInUser == null) {
				
				
				m.addAttribute("err", "Login Failed! Enter valid credentials.");
				return "login";

			} else
				
                
			{
				if (loggedInUser.getRole().equals(EmpService.ROLE_ADMINSTAFF)) {

					addUserInSession(loggedInUser, session);
					session.setAttribute("loggedInUser", loggedInUser);
					
					return "redirect:adminstaff/dashboard";
				} else if (loggedInUser.getRole().equals(EmpService.ROLE_EMP)) {

					addUserInSession(loggedInUser, session);
					session.setAttribute("loggedInUser", loggedInUser);
					System.out.println(loggedInUser + "");
				
					return "redirect:user/dashboard";
				} else {

					m.addAttribute("err", "Invalid User ROLE");
					return "index";
				}
			}
		} catch (EmpBlockedException ex) {

			m.addAttribute("err", ex.getMessage());
			System.out.println("msg"+ex.getMessage());
			return "redirect:login1?act=login";
		}
	}


	/**
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:index?act=lo";
	}

	/**
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/home")
	public String home(HttpSession session) {
		session.invalidate();
		return "redirect:index?act=home";
	}

	/**
	 * @param m
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/user/dashboard")
	public String userDashboard(ModelMap m, HttpSession session) {
		System.out.println("In user dashboard" + session.getAttribute("loggedInUser"));
		m.addAttribute("employee", session.getAttribute("loggedInUser"));
		return "dashboard_user";
	}

	/**
	 * @param m
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/profile")
	public String userProfile(ModelMap m, HttpSession session) {
//		System.out.println("In user dashboard"+session.getAttribute("loggedInUser"));
		m.addAttribute("employee", session.getAttribute("loggedInUser"));
		return "profile";
	}

	/**
	 * @param m
	 * @return
	 */
	@RequestMapping(value = "/reg_form")
	public String registrationForm(Model m) {
		EmpCommand cmd = new EmpCommand();
		m.addAttribute("command", cmd);
		return "reg_form";
	}

	/**
	 * @param cmd
	 * @param m
	 * @return
	 */
	@RequestMapping(value = "/register")
	public String registerUser(@ModelAttribute("command") EmpCommand cmd, Model m) {
		try {
			Emp user = cmd.getUser();
			user.setRole(EmpService.ROLE_EMP);
			user.setLoginStatus(EmpService.LOGIN_STATUS_ACTIVE);
			userService.register(user);
			/* m.addAttribute("login", "Register Successfully..."); */
			return "redirect:login1?act=reg";
		} catch (DuplicateKeyException e) {
			e.printStackTrace();
			m.addAttribute("err", "Username is already registered. Please select another username.");
			return "reg_form";
		}
	}

	/**
	 * @param u
	 * @param session
	 */
	private void addUserInSession(Emp u, HttpSession session) {
		session.setAttribute("user", u);
		session.setAttribute("userId", u.getUserId());
		session.setAttribute("role", u.getRole());
	}

	/**
	 * @param username
	 * @return
	 */
	@RequestMapping(value = "/check_avail")
	@ResponseBody
	public String checkAvailability(@RequestParam String username) {
		if (userService.isUsernameExist(username)) {
			return "This username is already taken. Choose another name";
		} else {
			return "Yes! You can take this username";
		}
	}

	/**
	 * @param m
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/adminstaff/dashboard")
	public String adminDashboard(ModelMap m, HttpSession session) {
		m.addAttribute("adminstaff", session.getAttribute("loggedInUser"));
		return "dashboard_adminstaff";
	}

	/**
	 * @param m
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/adminstaffprofile1")
	public String adminstaffProfile(ModelMap m, HttpSession session) {

		m.addAttribute("adminstaff", session.getAttribute("loggedInUser"));
		return "adminstaffprofile";
	}

	/**
	 * @param m
	 * @return
	 */
	@RequestMapping(value = "/admin/users")
	public String getUserList(Model m) {

		m.addAttribute("userList", userService.getUserList());
		return "users";
	}

	/*
	 * @RequestMapping(value = "/admin/users/{page_id}") public String
	 * getUserList(Model m,@PathVariable int page_id) { int total = 10; if(page_id
	 * == 1) { // do nothing! } else { page_id= (page_id-1)*total+1; }
	 * 
	 * m.addAttribute("userList", userService.getUserList(page_id, total)); return
	 * "users"; }
	 */

	/**
	 * @param userId
	 * @param m
	 * @return
	 */
	@RequestMapping(value = "/user/del_emp")
	public String deleteEmp(@RequestParam("userId") Integer userId, Model m) {

		userService.delete(userId);
		m.addAttribute("userList", userService.getUserList());
		return "users";
	}

	/*
	 * @RequestMapping(value = "/user/del_emp/{page_id}") public String
	 * deleteEmp(@RequestParam("userId") Integer userId, Model m,@PathVariable int
	 * page_id) { int total = 10; if(page_id == 1) { // do nothing! } else {
	 * page_id= (page_id-1)*total+1; }
	 * 
	 * userService.delete(userId); m.addAttribute("userList",
	 * userService.getUserList(page_id, total)); return "users"; }
	 */

	/**
	 * @param userIds
	 * @return
	 */
	@RequestMapping(value = "/user/bulk_udelete")
	public String deleteBulkContact(@RequestParam("userId") Integer[] userIds) {
		userService.delete(userIds);
		return "users";
	}

	/**
	 * @param userId
	 * @param loginStatus
	 * @return
	 */
	@RequestMapping(value = "/admin/change_status")
	@ResponseBody
	public String changeLoginStatus(@RequestParam Integer userId, @RequestParam Integer loginStatus) {
		try {
			userService.changeLoginStatus(userId, loginStatus);
			return "SUCCESS: Status Changed";
		} catch (Exception e) {
			e.printStackTrace();
			return "ERROR: Unable to Change Status";
		}
	}

	/**
	 * @param m
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/user/lops")
	public String userLOPS(Model m, HttpSession session) {
		Integer userId = (Integer) session.getAttribute("userId");
		System.out.println(userId);
		List<Attend> attendList = attendanceService.findByUserId(userId);
		System.out.println(attendList);
		m.addAttribute("attendList", attendList);
		return "view_lops"; // JSP
	}

	/**
	 * @param m
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/user/attendance")
	public String userattendance(Model m, HttpSession session) {
		Integer userId = (Integer) session.getAttribute("userId");
		System.out.println(userId);
		List<Attend> attendList = attendanceService.findByUserId(userId);
		System.out.println(attendList);
		m.addAttribute("attendList", attendList);
		return "viewattendance"; // JSP
	}

	/**
	 * @param m
	 * @param session
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "/edit_Emp")
	public String prepareEditForm(Model m, HttpSession session,
			@RequestParam(value = "aUserId", required = true) Integer userId) {
		session.setAttribute("aUserId", userId);
		Emp u = userService.findById(userId);
		m.addAttribute("command", u);
		System.out.println("edit" + u);
		return "Empedit";
	}

	/**
	 * @param u
	 * @param m
	 * @param a
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/EditEmp")
	public String update(@ModelAttribute("command") Emp u, Model m, ModelMap a, HttpSession session) {

		Integer userId = (Integer) session.getAttribute("aUserId");
		System.out.println("userId" + userId);
		System.out.println(userId);

		if (userId != null) {

			try {

				u.setUserId(userId);

				userService.update(u);

				session.getAttribute("aUserId");

			
				// a.addAttribute("employee",session.getAttribute("loggedInUser"));
				m.addAttribute("userList", userService.getUserList());
				/* a.addAttribute("employee",session.getAttribute("loggedInUser")); */

				return "users";
			} catch (Exception e) {
				e.printStackTrace();
				m.addAttribute("err", "Failed to Edit Emp");
				return "Empedit";
			}

		}
		return "users";
	}

	/*
	 * @RequestMapping(value = "/EditEmp/{page_id}") public String
	 * update(@ModelAttribute("command") Emp u, Model m, ModelMap a, HttpSession
	 * session,@PathVariable int page_id) {
	 * 
	 * 
	 * Integer userId = (Integer) session.getAttribute("aUserId");
	 * System.out.println("userId" +userId); System.out.println(userId);
	 * 
	 * if(userId !=null) {
	 * 
	 * try {
	 * 
	 * u.setUserId(userId);
	 * 
	 * userService.update(u);
	 * 
	 * session.getAttribute("aUserId");
	 * 
	 * int total = 10; if(page_id == 1) { // do nothing! } else { page_id=
	 * (page_id-1)*total+1; } //
	 * a.addAttribute("employee",session.getAttribute("loggedInUser"));
	 * m.addAttribute("userList",userService.getUserList(page_id, total));
	 * a.addAttribute("employee",session.getAttribute("loggedInUser"));
	 * 
	 * 
	 * return "users"; } catch(Exception e) { e.printStackTrace();
	 * m.addAttribute("err", "Failed to Edit Emp"); return"Empedit"; }
	 * 
	 * } return "users"; }
	 */

	/**
	 * @param u
	 * @param m
	 * @param session
	 * @param freeText
	 * @return
	 */
	@RequestMapping(value = "/user/users_search")
	public String userSearch(@ModelAttribute("command") Emp u, Model m, HttpSession session,
			@RequestParam("freeText") String freeText) {
		// Integer userId = (Integer) session.getAttribute("userId");
		// System.out.println("userId"+userId);
		m.addAttribute("userList", userService.findUser(freeText));
		return "users";
	}

}
