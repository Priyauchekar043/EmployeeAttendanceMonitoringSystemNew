package com.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.model.Attend;
import com.service.AttendanceService;
import com.service.EmpService;
import com.service.LeaveService;

@Controller
public class AttendanceController {

	@Autowired
	private AttendanceService attendanceService;
	@Autowired
	private LeaveService leaveService;

	/**
	 * @param m
	 * @return
	 */
	@RequestMapping(value = "/user1/attend_form")
	public String contactForm(Model m) {
		Attend attend = new Attend();
		m.addAttribute("command", attend);
		return "attendform1";// JSP form view
	}

	/**
	 * @param s
	 * @param m
	 * @param session
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(value = "/user/save_attend")
	public String attendsave(@ModelAttribute("command") Attend s, Model m, HttpSession session) throws ParseException {
		Integer aId = (Integer) session.getAttribute("aAId");
		//String pattern="MM/yyyy";
		//SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
//		s.setDate(simpleDateFormat.format(new Date()));
		//String temp=simpleDateFormat.format(s.getDate());
		//System.out.println(temp);
		//s.setDate(simpleDateFormat.parse(temp));
		//System.out.println("date is comming"+s+"aid"+aId);
		s.setEmpleave(2);
		s.setSalary(30000);
		if (aId == null) {
			// save task
			try {
				Integer userId = (Integer) session.getAttribute("userId");
				System.out.println("userId " + userId);
				s.setUserId(userId);// FK ; logged in userId
				attendanceService.save(s);
				m.addAttribute("attendlist", "Attendance fillup successfully");
				return "attendform1";// redirect user to contact list url
			} catch (Exception e) {
				e.printStackTrace();
				m.addAttribute("err", "Failed to save attendance");
				return "attendform1";
			}
		
		}
		
		return "attendform1";
	
	}	
	/**
	 * @param s
	 * @param m
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/user/update_attend")
	public String attendupdate(@ModelAttribute("command") Attend s, Model m, HttpSession session)
	
	{
		if (s.getEmpleave()==2) {
			
            s.setTotalattenddays(s.getAttenddays());
			  
			  System.out.println("nothing change"+ s);
		} else 
		
		{
			if (s.getEmpleave()<2){
				
				s.setTotalattenddays(s.getAttenddays());
				  System.out.println(" change by 1"+ s);
			} else if (s.getEmpleave()>2){
				
				s.setTotalattenddays(s.getAttenddays()-s.getEmpleave()+2);
				  System.out.println(" change by 2"+ s);
				  
			} else {
				
				 s.setTotalattenddays(s.getAttenddays()+ s.getEmpleave());
				 System.out.println(" change by 2"+ s);
			}
		}
		
		
		/*
		 * if(s.getEmpleave()>2)
		 * 
		 * { s.setTotalattenddays(s.getAttenddays()-s.getEmpleave());
		 * System.out.println(" change"+ s);
		 * 
		 * 
		 * } else {
		 * 
		 * s.setTotalattenddays(s.getAttenddays());
		 * 
		 * System.out.println("nothing change"+ s); }
		 */
		 
		/* s.setTotalattenddays(s.getAttenddays()-s.getEmpleave()); */
		System.out.println("Data"+ s);
		Integer aId = (Integer) session.getAttribute("aAId");
		System.out.println("aId" +aId);
		if (aId != null) {
			// save task
			try {
		
				 
				 s.setaId(aId);// PK 
				  attendanceService.update(s);
				  System.out.println(s);
				session.removeAttribute("aAId");
				  m.addAttribute("attendList", attendanceService.getattendList());
			  return "attendlist";
			}
			  catch (Exception e) {
				  e.printStackTrace(); 
				  m.addAttribute("err", "Failed to Edit attendance");
				  return "EditAttend"; 
				  }
	
	
	


	}
		return "attendlist";
	}
	
	
	
	/**
	 * @param m
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/user/attendlist")
    public String AttendList(Model m, HttpSession session) {
       
        m.addAttribute("attendList", attendanceService.getattendList());
        return "attendlist"; //JSP
    }
	
	/**
	 * @param m
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/user/attendlist1")
    public String AttendList1(Model m, HttpSession session) {
       
        m.addAttribute("attendList", attendanceService.getattendList());
        return "calculatelop"; //JSP
    }
	
	
	/**
	 * @param m
	 * @param session
	 * @param aId
	 * @return
	 */
	@RequestMapping(value = "/user/edit_attend")
    public String prepareEditForm(Model m, HttpSession session, @RequestParam(value="aid",required =true) Integer aId) {
        session.setAttribute("aAId", aId);
        System.out.println();
        Attend s = attendanceService.findById(aId);
        m.addAttribute("command", s);
        System.out.println(s);
        return "EditAttend";//JSP form view
    }
}
