package com.controller;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.command.AdminCommand;
import com.model.Admin;
import com.service.AdminService;




@Controller
public class AdminController {

    @Autowired
    private AdminService adminService;

    /**
     * @param m
     * @return
     */
    @RequestMapping(value = "/user/admin_form")
    public String contactForm(Model m) {
        Admin contact = new Admin();
        m.addAttribute("command", contact);
        return "admin_form";//JSP form view
    }

	

    /**
     * @param c
     * @param m
     * @param session
     * @return
     */
    @RequestMapping(value = "/user/save_contact")
    public String saveOrUpdateContact(@ModelAttribute("command") Admin c, Model m, HttpSession session) {
		
            try {
				 Integer adminId = (Integer) session.getAttribute("adminId");
                c.setAdminId(adminId);
                adminService.save(c);
                m.addAttribute("contactList", "Admin Registered Successfully. Please login");
              return "adminlogin";
			/* return "redirect:adminlogin?act=reg1"; */
            } catch (Exception e) {
                e.printStackTrace();
                m.addAttribute("err", "Failed to save Admin");
                return "admin_form";
            
        
		} 
    }	

  

    /**
     * @param m
     * @param session
     * @return
     */
    @RequestMapping(value = "/admin/dashboard")
	public String adminDashboard(ModelMap m,HttpSession session) {
    	
    	System.out.println("In admin dashboard"+session.getAttribute("loggedInUser"));
		m.addAttribute("admin",session.getAttribute("loggedInUser"));
    	
		return "dashboard_admin"; 
	}

    /**
     * @param cmd
     * @return
     */
    @RequestMapping(value = "/showadminlogin")
    public String adminLogin1(@ModelAttribute("command") AdminCommand cmd) {
    	return "adminlogin";
    }
    
	
	  /**
	 * @param cmd
	 * @param m
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/adminlogin",method = { RequestMethod.GET, RequestMethod.POST })
	  public String adminLogin(@ModelAttribute("command") AdminCommand cmd, Model m, HttpSession
	  session) { 
		  
		   
		 Admin loggedInUser = adminService.login(cmd.getEmail(),cmd.getPassword()); 
			 
	
				 if(loggedInUser == null)
				 {
						
					 addUserInSession(loggedInUser, session); 
			           // System.out.println(loggedInUser);
			 
					 m.addAttribute("err", "Login Failed! Enter valid credentials."); 
					 return "adminlogin";
	           
			  
				 }
				 else {
			
					 addUserInSession(loggedInUser, session); 
			            m.addAttribute(loggedInUser);
			            session.setAttribute("loggedInUser", loggedInUser);
						
			            
			            return "redirect:admin/dashboard";   
					 
				 }
	  
		  
	  
	  }
	  
	  private void addUserInSession(Admin c, HttpSession session) { 
		  session.setAttribute("admin", c);
		/*
		 * session.setAttribute("email", c.getEmail()); session.setAttribute("password",
		 * c.getPassword());
		 */
	  
	  }  
	  
	  /**
	 * @param m
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/adminprofile1")
		public String userProfile(ModelMap m,HttpSession session) {
//			System.out.println("In user dashboard"+session.getAttribute("loggedInUser"));
			m.addAttribute("admin",session.getAttribute("loggedInUser"));
			return "adminprofile";
		}
	  
	  
	  
	  
	  /**
	 * @param m
	 * @return
	 */
	@RequestMapping(value = "/user/clist")
	    public String getContactList(Model m) {
	       
	        m.addAttribute("contactList", adminService.getContactList());
	        return "adminlist"; //JSP
	    }
}

